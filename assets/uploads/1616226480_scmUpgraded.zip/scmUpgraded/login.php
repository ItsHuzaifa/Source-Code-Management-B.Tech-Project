<?php

ech "hi";
?>