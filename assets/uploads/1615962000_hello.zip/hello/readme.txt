This is android project , 

required funcs:

1
2
3