make UI 1st
